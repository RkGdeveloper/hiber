package com.cg.studentscore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.studentscore.dbutil.JPAUtil;
import com.cg.studentscore.entities.Department;
import com.cg.studentscore.entities.Student;

public class StudentScoreDAOImpl implements IStudentScoreDAO {

	EntityManager em;
	public StudentScoreDAOImpl() {
		em = JPAUtil.getEntityManager();
	}
	
	@Override
	public List<Student> getAllStudent() {

		List<Student> studList = null;
			studList = em.createQuery("SELECT new com.cg.studentscore.entities.Student(s.studNo,s.studName,s.studPhone,s.studAddr,s.studDept) FROM Student s",
				Student.class).getResultList();
			
		return studList;
	
	}

	@Override
	public List<Department> getAllDept() {
		List<Department> deptList = null;
		deptList = em.createQuery("SELECT new com.cg.studentscore.entities.Department(d.deptNo,d.deptName,d.deptLoc) FROM Department d",
			Department.class).getResultList();
		
	return deptList;
	}

	@Override
	public List<Student> getStudentByDepartmentName(String dName) {
		List<Student> studList = null;
		
		String sqlQuery = "SELECT new com.cg.studentscore.entities.Student(s.studNo,s.studName,s.studPhone,s.studAddr,s.studDept) FROM Student s,Department d WHERE d.deptNo = s.studDept AND d.deptName = :deptName";
		TypedQuery<Student> q = em.createQuery(sqlQuery,Student.class);
		q.setParameter("deptName", dName);
		studList = q.getResultList();
		System.out.println("in dao");
		return studList;
	}

	@Override
	public List<Student> getStudentByAddress(String addr) {
		List<Student> studList = null; 
		String addrQ ="SELECT new com.cg.studentscore.entities.Student(s.studNo,s.studName,s.studPhone,s.studAddr,s.studDept) FROM Student s WHERE s.studAddr = :address";
		TypedQuery<Student> q = em.createQuery(addrQ,Student.class);
		q.setParameter("address", addr);
		studList = q.getResultList();
		return studList;
	}

	@Override
	public Department getDepartmentById(int dno) {
		String deptQ = "SELECT new com.cg.studentscore.entities.Department(dept.deptNo,dept.deptName,dept.deptLoc) FROM Department dept WHERE dept.deptNo = :deptno";
		TypedQuery<Department> tDept = em.createQuery(deptQ,Department.class);
		tDept.setParameter("deptno", dno);
		Department d = tDept.getSingleResult();
		return d;
	}

	@Override
	public void addStudentDetails(Student stud) {
	/*	em.getTransaction().begin();
		em.persist(stud);
		em.getTransaction().commit();
	*/}

}
