package com.cg.studentscore.dao;

import java.util.List;

import com.cg.studentscore.entities.Department;
import com.cg.studentscore.entities.Student;

public interface IStudentScoreDAO {

	List<Student> getAllStudent();

	List<Department> getAllDept();

	List<Student> getStudentByDepartmentName(String dName);

	List<Student> getStudentByAddress(String addr);

	Department getDepartmentById(int dno);

	void addStudentDetails(Student stud);

}
