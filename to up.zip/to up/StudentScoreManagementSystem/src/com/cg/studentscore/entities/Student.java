package com.cg.studentscore.entities;

import java.io.Serializable;

import javax.persistence.*;


@Entity
@Table(name="student")
public class Student implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="sid", sequenceName="St_seq")  
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator= "sid")
	@Column(name="studno")
	private int studNo;
	
	private String studName;
	
	@Column(name="phone")
	private long studPhone;
	
	@Column(name="address")
	private String studAddr;
	
	@Column(name="deptno")
	private int studDept;

	public Student(){}
	
	/*@ManyToOne
	@JoinColumn(name="deptno")
	private Department department;

	
	
	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}*/

	public int getStudNo() {
		return studNo;
	}

	public void setStudNo(int studNo) {
		this.studNo = studNo;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public long getStudPhone() {
		return studPhone;
	}

	public void setStudPhone(long studPhone) {
		this.studPhone = studPhone;
	}

	public String getStudAddr() {
		return studAddr;
	}

	public void setStudAddr(String studAddr) {
		this.studAddr = studAddr;
	}

	public int getStudDept() {
		return studDept;
	}

	public void setStudDept(int studDept) {
		this.studDept = studDept;
	}

	@Override
	public String toString() {
		return "Student [studNo=" + studNo + ", studName=" + studName
				+ ", studPhone=" + studPhone + ", studAddr=" + studAddr
				+ ", studDept=" + studDept + "]";
	}

	public Student(int studNo, String studName, long studPhone,
			String studAddr, int studDept) {
		this.studNo = studNo;
		this.studName = studName;
		this.studPhone = studPhone;
		this.studAddr = studAddr;
		this.studDept = studDept;
	}
	
	
}
