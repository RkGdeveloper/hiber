package com.cg.studentscore.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="department")
public class Department implements Serializable{

	/**
	 * 
	 */
	
	public Department(){}
	private static final long serialVersionUID = 1L;

	@Id
	private int deptNo;
	
	@Column(name="dname")
	private String deptName;
	
	@Column(name="loc")
	private String deptLoc;

	
/*	
	@OneToMany(mappedBy="department",cascade=CascadeType.ALL)
	private Set<Student> students = new HashSet<>();		//Initialization required to avoid NullPointerException

	
	
	
	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	
	//the method below will add employee to department 
		//also serves the purpose to avoid cyclic references. 
		public void addStudent(Student stud) {
			stud.setDepartment(this);
			this.getStudents().add(stud);
			//employee.setDepartment(this);			//this will avoid nested cascade
			//this.getEmployees().add(employee);
		}*/
		
		
	
	public int getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptLoc() {
		return deptLoc;
	}

	public void setDeptLoc(String deptLoc) {
		this.deptLoc = deptLoc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Department [deptNo=" + deptNo + ", deptName=" + deptName
				+ ", deptLoc=" + deptLoc + "]";
	}

	public Department(int deptNo, String deptName, String deptLoc) {
		super();
		this.deptNo = deptNo;
		this.deptName = deptName;
		this.deptLoc = deptLoc;
	}
	
	
}
