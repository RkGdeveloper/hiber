package com.cg.studentscore.service;

import java.util.List;

import com.cg.studentscore.entities.Department;
import com.cg.studentscore.entities.Student;

public interface IStudentScoreService {

	List<Student> getAllStudent();

	List<Department> getAllDept();

	List<Student> getStudentByDepartmentName(String dName);

	List<Student> getStudentByAddress(String addr);

	Department getDepartmetById(int dno);

	void addStudentDetails(Student stud);

}
