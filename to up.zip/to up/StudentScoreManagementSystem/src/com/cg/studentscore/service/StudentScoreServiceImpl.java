package com.cg.studentscore.service;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.studentscore.dao.IStudentScoreDAO;
import com.cg.studentscore.dao.StudentScoreDAOImpl;
import com.cg.studentscore.dbutil.JPAUtil;
import com.cg.studentscore.entities.Department;
import com.cg.studentscore.entities.Student;


public class StudentScoreServiceImpl implements IStudentScoreService {

	
	
	IStudentScoreDAO isd = new StudentScoreDAOImpl();
	@Override
	public List<Student> getAllStudent() {
		return isd.getAllStudent();
	}
	@Override
	public List<Department> getAllDept() {
		return isd.getAllDept();
	}
	@Override
	public List<Student> getStudentByDepartmentName(String dName) {
	
		System.out.println("in service layer");
		return isd.getStudentByDepartmentName(dName);
	}
	@Override
	public List<Student> getStudentByAddress(String addr) {
		return isd.getStudentByAddress(addr);
	}
	@Override
	public Department getDepartmetById(int dno) {
		return isd.getDepartmentById(dno);
	}
	@Override
	public void addStudentDetails(Student stud) {
		isd.addStudentDetails(stud);		
	}

	
}
