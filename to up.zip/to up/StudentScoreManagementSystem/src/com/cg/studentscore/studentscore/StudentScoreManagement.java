package com.cg.studentscore.studentscore;

import java.util.List;
import java.util.Scanner;

import com.cg.studentscore.entities.Department;
import com.cg.studentscore.entities.Student;
import com.cg.studentscore.service.IStudentScoreService;
import com.cg.studentscore.service.StudentScoreServiceImpl;

public class StudentScoreManagement {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		IStudentScoreService iss = new StudentScoreServiceImpl();
		
		while(true)
		{
		System.out.println("\n============================================"
				+ "\n1:Get All Students Details"
				+ "\n2:Get All Departments Details"
				+ "\n3:Insert Student into Table"
				+ "\n4:Get Students Name based on Department Name"
				+ "\n5:Get Students Name based on Address"
				+ "\n6:Get Department By Id<Typed Query>"
				+ "\n8:Exit"
				+ "\n============================================");
		int choice = sc.nextInt();
			switch(choice){
			case 1:
				{
					List<Student> studList = iss.getAllStudent();
					for(Student s:studList){
						System.out.println(s);
					}
				}
			break;
			
			
			case 2:
				{
					List<Department> deptList = iss.getAllDept();
					for(Department d:deptList){
						System.out.println(d);
					}
				}
			break;
			
			case 3:{
					/*Student stud = new Student();
					System.out.println("Enter Department Id of Student");
					int dno = sc.nextInt();
					stud.setStudDept(dno);
					System.out.println("Enter Student Name");
					stud.setStudName(sc.next());
					System.out.println("Enter Phone Number");
					stud.setStudPhone(sc.nextLong());
					System.out.println("Enter Address");
					stud.setStudAddr(sc.next());
					iss.addStudentDetails(stud);
					System.out.println("Data inserted successfull");*/
			}
				
			break;
			case 4:{
					System.out.println("Enter Department Name");
					String dName = sc.next();
					List<Student> studList= iss.getStudentByDepartmentName(dName);
					for(Student s:studList){
						System.out.println(s);
					}
				}
			break;
			
			case 5:{
					System.out.println("Enter Address");
					String addr = sc.next();
					List<Student> studList= iss.getStudentByAddress(addr);
					for(Student s:studList){
						System.out.println(s);
					}
				
				}
			break;
			
			case 6:{
				System.out.println("Enter Id of Department");
				int dno = sc.nextInt();
				Department dept = iss.getDepartmetById(dno);
				System.out.println(dept);
			}
			break;
			case 8:{
					System.out.println("Thank You..... ");
					System.exit(0);
				}
			}
		
	}
	}
}
