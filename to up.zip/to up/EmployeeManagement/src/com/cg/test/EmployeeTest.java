package com.cg.test;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class EmployeeTest {

public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Employee emp;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		System.out.println("Enter the number of Employee to insert");
		int limit = sc.nextInt();
		for(int i=0;i<limit;i++){
			
			emp = new Employee();
			/*
			 * 	System.out.println("Enter Id for Employee");
				emp.setEmpid(sc.nextInt());
			*/
			System.out.println("Enter Name for Employee");
			emp.setEname(sc.next());
			
			em.persist(emp);
			System.out.println("Added one student to database.");
		}
		
		em.getTransaction().commit();
		em.close();
		factory.close();
	}
	
}
