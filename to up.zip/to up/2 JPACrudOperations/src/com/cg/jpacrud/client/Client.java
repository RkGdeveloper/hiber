package com.cg.jpacrud.client;

import java.util.List;
import java.util.Scanner;

import com.cg.jpacrud.entities.Student;
import com.cg.jpacrud.service.StudentService;
import com.cg.jpacrud.service.StudentServiceImpl;

public class Client {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StudentService service = new StudentServiceImpl();
		Student student = new Student();
		
		while(true)
		{
		System.out.println("\n=====================\nEnter your choice:\n1:Add Student\n2:Find Student By Id\n3:Update Name By id \n4:Remove Student By Id\n5:Get All Stduent\n6:Exit\n=====================\n");
		int choice =sc.nextInt();
			switch(choice){
			case 1:{
				System.out.println("Enter Id of Stduent");
				student.setStudentId(sc.nextInt());
				System.out.println("Enter Name of Stduent");
				student.setName(sc.next());
				service.addStudent(student);
			}
			break;
			case 2:{
				System.out.println("Enter Id of Student");
				int id = sc.nextInt();
				student = service.findStudentById(id);
				
				System.out.println("::::::    Details are    ::::::\n");
				System.out.print("ID:"+student.getStudentId()+"\n");
				System.out.println(" Name:"+student.getName()+"\n");
				
			}
			break;
			
			case 3:{
				System.out.println("Enter Id of Student");
				int id = sc.nextInt();
				student = service.findStudentById(id);
				System.out.println("Enter name of Student to update");
				String name = sc.next();
				student.setName(name);
				service.updateStudent(student);				
			}
			break;
			case 4:{
				System.out.println("Enter Id of Student");
				int id = sc.nextInt();
				student = service.findStudentById(id);
				service.removeStudent(student);
			}
			break;
			case 5:{
				List<Student> studList = service.getAllStudent();
				System.out.println("\n=====================\n");
				for(Student s : studList)
					System.out.println(s);
				System.out.println("\n=====================\n");
			}
			break;
			case 6:{
				System.out.println("Thank you....");
				System.exit(0);
			}
			break;
			}
			System.out.println("\n=====================\n");

		}
	
	}
}
